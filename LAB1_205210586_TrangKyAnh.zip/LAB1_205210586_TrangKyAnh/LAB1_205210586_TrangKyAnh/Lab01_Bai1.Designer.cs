﻿namespace LAB1_205210586_TrangKyAnh
{
    partial class Lab01_Bai1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.Firstnum = new System.Windows.Forms.Label();
            this.Secondnum = new System.Windows.Forms.Label();
            this.Result = new System.Windows.Forms.Label();
            this.firstInt = new System.Windows.Forms.TextBox();
            this.secondInt = new System.Windows.Forms.TextBox();
            this.ResultInt = new System.Windows.Forms.TextBox();
            this.GetResult = new System.Windows.Forms.Button();
            this.getRes = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Title.AutoSize = true;
            this.Title.BackColor = System.Drawing.Color.Transparent;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.OrangeRed;
            this.Title.Location = new System.Drawing.Point(110, 25);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(580, 51);
            this.Title.TabIndex = 0;
            this.Title.Text = "TÍNH TỔNG 2 SỐ NGUYÊN";
            // 
            // Firstnum
            // 
            this.Firstnum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Firstnum.AutoSize = true;
            this.Firstnum.BackColor = System.Drawing.Color.Transparent;
            this.Firstnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Firstnum.Location = new System.Drawing.Point(50, 150);
            this.Firstnum.Name = "Firstnum";
            this.Firstnum.Size = new System.Drawing.Size(141, 26);
            this.Firstnum.TabIndex = 1;
            this.Firstnum.Text = "Số thứ nhất:";
            // 
            // Secondnum
            // 
            this.Secondnum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Secondnum.AutoSize = true;
            this.Secondnum.BackColor = System.Drawing.Color.Transparent;
            this.Secondnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Secondnum.Location = new System.Drawing.Point(50, 250);
            this.Secondnum.Name = "Secondnum";
            this.Secondnum.Size = new System.Drawing.Size(127, 26);
            this.Secondnum.TabIndex = 2;
            this.Secondnum.Text = "Số thứ hai:";
            // 
            // Result
            // 
            this.Result.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Result.AutoSize = true;
            this.Result.BackColor = System.Drawing.Color.Transparent;
            this.Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.Location = new System.Drawing.Point(50, 350);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(101, 26);
            this.Result.TabIndex = 3;
            this.Result.Text = "Kết quả:";
            // 
            // firstInt
            // 
            this.firstInt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.firstInt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.firstInt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstInt.Location = new System.Drawing.Point(250, 150);
            this.firstInt.Name = "firstInt";
            this.firstInt.Size = new System.Drawing.Size(400, 32);
            this.firstInt.TabIndex = 4;
            // 
            // secondInt
            // 
            this.secondInt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.secondInt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.secondInt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondInt.Location = new System.Drawing.Point(250, 250);
            this.secondInt.Name = "secondInt";
            this.secondInt.Size = new System.Drawing.Size(400, 32);
            this.secondInt.TabIndex = 5;
            // 
            // ResultInt
            // 
            this.ResultInt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ResultInt.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ResultInt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResultInt.Location = new System.Drawing.Point(250, 350);
            this.ResultInt.Name = "ResultInt";
            this.ResultInt.Size = new System.Drawing.Size(400, 32);
            this.ResultInt.TabIndex = 6;
            // 
            // GetResult
            // 
            this.GetResult.BackColor = System.Drawing.Color.Transparent;
            this.GetResult.Location = new System.Drawing.Point(1219, 201);
            this.GetResult.Name = "GetResult";
            this.GetResult.Size = new System.Drawing.Size(75, 23);
            this.GetResult.TabIndex = 7;
            this.GetResult.UseVisualStyleBackColor = false;
            // 
            // getRes
            // 
            this.getRes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.getRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getRes.Location = new System.Drawing.Point(675, 150);
            this.getRes.Name = "getRes";
            this.getRes.Size = new System.Drawing.Size(100, 35);
            this.getRes.TabIndex = 8;
            this.getRes.Text = "Tính";
            this.getRes.UseVisualStyleBackColor = true;
            this.getRes.Click += new System.EventHandler(this.getRes_Click);
            // 
            // Clear
            // 
            this.Clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.Location = new System.Drawing.Point(675, 250);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(100, 35);
            this.Clear.TabIndex = 9;
            this.Clear.Text = "Xóa";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Close
            // 
            this.Close.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Close.Location = new System.Drawing.Point(675, 350);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(100, 35);
            this.Close.TabIndex = 10;
            this.Close.Text = "Thoát";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Exercise1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.BackgroundImage = global::LAB1_205210586_TrangKyAnh.Properties.Resources.yuriy_kovalev_nN1HSDtKdlw_unsplash;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.getRes);
            this.Controls.Add(this.GetResult);
            this.Controls.Add(this.ResultInt);
            this.Controls.Add(this.secondInt);
            this.Controls.Add(this.firstInt);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.Secondnum);
            this.Controls.Add(this.Firstnum);
            this.Controls.Add(this.Title);
            this.Name = "Exercise1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab1 - 20521086 - Trang Kỳ Anh - Exercise 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label Firstnum;
        private System.Windows.Forms.Label Secondnum;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.TextBox firstInt;
        private System.Windows.Forms.TextBox secondInt;
        private System.Windows.Forms.TextBox ResultInt;
        private System.Windows.Forms.Button GetResult;
        private System.Windows.Forms.Button getRes;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Close;
    }
}