﻿namespace LAB1_205210586_TrangKyAnh
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Bai1 = new System.Windows.Forms.Button();
            this.Bai2 = new System.Windows.Forms.Button();
            this.Bai3 = new System.Windows.Forms.Button();
            this.Bai4 = new System.Windows.Forms.Button();
            this.Bai5 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Bai1
            // 
            this.Bai1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Bai1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bai1.Location = new System.Drawing.Point(100, 150);
            this.Bai1.Name = "Bai1";
            this.Bai1.Size = new System.Drawing.Size(200, 50);
            this.Bai1.TabIndex = 1;
            this.Bai1.Text = "Bài 1";
            this.Bai1.UseVisualStyleBackColor = true;
            this.Bai1.Click += new System.EventHandler(this.Bai1_Click);
            // 
            // Bai2
            // 
            this.Bai2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Bai2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bai2.Location = new System.Drawing.Point(500, 150);
            this.Bai2.Name = "Bai2";
            this.Bai2.Size = new System.Drawing.Size(200, 50);
            this.Bai2.TabIndex = 2;
            this.Bai2.Text = "Bài 2";
            this.Bai2.UseVisualStyleBackColor = true;
            this.Bai2.Click += new System.EventHandler(this.Bai2_Click);
            // 
            // Bai3
            // 
            this.Bai3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Bai3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bai3.Location = new System.Drawing.Point(300, 250);
            this.Bai3.Name = "Bai3";
            this.Bai3.Size = new System.Drawing.Size(200, 50);
            this.Bai3.TabIndex = 3;
            this.Bai3.Text = "Bài 3";
            this.Bai3.UseVisualStyleBackColor = true;
            this.Bai3.Click += new System.EventHandler(this.Bai3_Click);
            // 
            // Bai4
            // 
            this.Bai4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Bai4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bai4.Location = new System.Drawing.Point(100, 350);
            this.Bai4.Name = "Bai4";
            this.Bai4.Size = new System.Drawing.Size(200, 50);
            this.Bai4.TabIndex = 4;
            this.Bai4.Text = "Bài 4";
            this.Bai4.UseVisualStyleBackColor = true;
            this.Bai4.Click += new System.EventHandler(this.Bai4_Click);
            // 
            // Bai5
            // 
            this.Bai5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Bai5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bai5.Location = new System.Drawing.Point(500, 350);
            this.Bai5.Name = "Bai5";
            this.Bai5.Size = new System.Drawing.Size(200, 50);
            this.Bai5.TabIndex = 5;
            this.Bai5.Text = "Bài 5";
            this.Bai5.UseVisualStyleBackColor = true;
            this.Bai5.Click += new System.EventHandler(this.Bai5_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OrangeRed;
            this.label2.Location = new System.Drawing.Point(234, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(328, 51);
            this.label2.TabIndex = 8;
            this.label2.Text = "BÀI TẬP LAB 1";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.BackgroundImage = global::LAB1_205210586_TrangKyAnh.Properties.Resources.yuriy_kovalev_nN1HSDtKdlw_unsplash;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(832, 503);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Bai5);
            this.Controls.Add(this.Bai4);
            this.Controls.Add(this.Bai3);
            this.Controls.Add(this.Bai2);
            this.Controls.Add(this.Bai1);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab1 - 20521086 - Trang Kỳ Anh - Main Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Bai1;
        private System.Windows.Forms.Button Bai2;
        private System.Windows.Forms.Button Bai3;
        private System.Windows.Forms.Button Bai4;
        private System.Windows.Forms.Button Bai5;
        private System.Windows.Forms.Label label2;
    }
}

